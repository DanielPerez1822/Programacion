package com.corhuila.tareainicial.models.dao;

import com.corhuila.tareainicial.models.entity.Inventor;
import org.springframework.data.repository.CrudRepository;

public interface IInventorDao extends CrudRepository<Inventor, Long> {
}
